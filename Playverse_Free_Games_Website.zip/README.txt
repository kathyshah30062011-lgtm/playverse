PLAYVERSE — FREE BROWSER GAMES WEBSITE
========================================

FILES
- index.html: the website and 8 playable mini-games.
- README.txt: these instructions.

TRY IT
1. Extract the ZIP on your computer, or place index.html in a folder.
2. Open index.html in Chrome. The games run locally; no install is needed.
3. Tap ⚙ Admin to change the website name, heading, message and accent colours.
4. Those edits are saved in the current browser only.

IMPORTANT ABOUT THE "BACKEND"
This starter includes a simple local editor, NOT a shared online admin backend.
If you change the text on your phone, visitors on other devices will not see those
changes. A real shared admin panel needs authentication and a database (for example,
a free-tier backend service). Never put secret admin passwords or API keys in
index.html.

HOW TO PUT IT ONLINE FOR FREE
One beginner-friendly route is GitHub Pages:
1. Create a GitHub account at https://github.com/
2. Create a new public repository, for example "playverse-games".
3. Upload index.html (and optionally README.txt) to the repository root.
4. Open Settings -> Pages, choose deploy from branch, select main and /(root), save.
5. Wait for GitHub Pages to provide your public website address.
6. Open that address in Chrome and share it.

This is a free static-hosting option; availability and platform terms may change.
A live website does not automatically appear at the top of Google Search. To help
Google discover it, add the site in Google Search Console and request indexing:
https://search.google.com/search-console/about

OFFLINE NOTE
The games can run from the downloaded index.html without internet after it is saved.
Online hosting is needed for people to visit the same public URL. Some browsers
may restrict certain features when opened as a local file, but these games are
designed to work without a server.
